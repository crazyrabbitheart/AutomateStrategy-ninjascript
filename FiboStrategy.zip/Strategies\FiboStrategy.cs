#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class FiboStrategy : Strategy
	{
		private bool notrading = false;
		
		private DateTime 				currentDate 		=	Core.Globals.MinDate;
		private double					currentClose		=	0;
		private double					currentHigh			=	0;
		private double					currentLow			=	0;
		private double					currentOpen			=	0;
		private double					priorDayClose		=	0;
		private double					priorDayHigh		=	0;
		private double					priorDayLow			=	0;
		private double					priorDayOpen		=	0;
		private	Data.SessionIterator	sessionIterator;	
		
		private string[]  	atmStrategyId			= new string[10];
		private string[]  	orderId					= new string[10];
		private bool[]		isAtmStrategyCreated	= new bool[10];
		private int			MCL						= 0;		
		private double		realizedProfitLoss		= 0;			// Variable to hold a specific ATM strategy's profit/loss
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "FiboStrategy";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 5;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				StartTime					= DateTime.Parse("09:00", System.Globalization.CultureInfo.InvariantCulture);
				EndTime						= DateTime.Parse("17:00", System.Globalization.CultureInfo.InvariantCulture);
				Fibolevel1					= 0;
				Fibolevel2					= 2.5;
				Fibolevel3					= 5;
				Fibolevel4					= 7.5;
				Fibolevel5					= 10;
				Fibolevel6					= 90;
				Fibolevel7					= 92.5;
				Fibolevel8					= 95;
				Fibolevel9					= 97.5;
				Fibolevel10					= 100;
				DisableAfterSuccess			= true;
				DisableAfterFailed			= true;
				ShowFibo					= true;
				tradingFailedCount			= 5;
				
//				AddPlot(new Stroke(Brushes.SteelBlue,	DashStyleHelper.Dash,	2),	PlotStyle.Hash, NinjaTrader.Custom.Resource.PriorDayOHLCOpen);
//				AddPlot(new Stroke(Brushes.DarkCyan,							2),	PlotStyle.Hash, NinjaTrader.Custom.Resource.PriorDayOHLCHigh);
//				AddPlot(new Stroke(Brushes.Crimson,								2),	PlotStyle.Hash, NinjaTrader.Custom.Resource.PriorDayOHLCLow);
//				AddPlot(new Stroke(Brushes.SlateBlue,	DashStyleHelper.Dash,	2),	PlotStyle.Hash, NinjaTrader.Custom.Resource.PriorDayOHLCClose);
			}
			else if (State == State.Configure)
			{
				currentDate 	    = Core.Globals.MinDate;
				currentClose		= 0;
				currentHigh			= 0;
				currentLow			= 0;
				currentOpen			= 0;
				priorDayClose		= 0;
				priorDayHigh		= 0;
				priorDayLow			= 0;
				priorDayOpen		= 0;
				sessionIterator		= null;
				MCL					= 0;
				for (int i=0;i<10;i++){
					atmStrategyId[i] = string.Empty;
					orderId[i] = string.Empty;
					isAtmStrategyCreated[i] = false;
				}
			}
			else if (State == State.DataLoaded)
			{
				sessionIterator = new Data.SessionIterator(Bars);
			}
			else if (State == State.Historical)
			{
				if (!Bars.BarsType.IsIntraday)
				{
					Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.PriorDayOHLCIntradayError, TextPosition.BottomRight);
					Log(NinjaTrader.Custom.Resource.PriorDayOHLCIntradayError, LogLevel.Error);
				}
			}
		}

		protected override void OnBarUpdate()
		{
			if (!Bars.BarsType.IsIntraday)				return;
			if (CurrentBar < BarsRequiredToTrade)		return;			
			
			if (currentDate != sessionIterator.GetTradingDay(Time[0]) || currentOpen == 0)
			{
				// The current day OHLC values are now the prior days value so set
				// them to their respect indicator series for plotting
				priorDayOpen	= currentOpen;
				priorDayHigh	= currentHigh;
				priorDayLow		= currentLow;
				priorDayClose	= currentClose;

//				PriorOpen[0]	= priorDayOpen;
//				PriorHigh[0]	= priorDayHigh;
//				PriorLow[0]		= priorDayLow;
//				PriorClose[0]	= priorDayClose;

				// Initilize the current day settings to the new days data
				currentOpen 	=	Open[0];
				currentHigh 	=	High[0];
				currentLow		=	Low[0];
				currentClose	=	Close[0];

				currentDate 	=	sessionIterator.GetTradingDay(Time[0]);
				
				RemoveDrawObjects();
				MCL = 0;
				notrading = false;
			}
			else // The current day is the same day
			{
				// Set the current day OHLC values
				currentHigh 	=	Math.Max(currentHigh, High[0]);
				currentLow		=	Math.Min(currentLow, Low[0]);
				currentClose	=	Close[0];

//				PriorOpen[0] 	= priorDayOpen;
//				PriorHigh[0] 	= priorDayHigh;
//				PriorLow[0] 	= priorDayLow;
//				PriorClose[0] 	= priorDayClose;
			}
			
//			Print(priorDayHigh);
//			Print(priorDayLow);
			
			double step = (priorDayHigh - priorDayLow) / 100;
			double fibo1 = priorDayLow + Fibolevel1 * step;
			double fibo2 = priorDayLow + Fibolevel2 * step;
			double fibo3 = priorDayLow + Fibolevel3 * step;
			double fibo4 = priorDayLow + Fibolevel4 * step;
			double fibo5 = priorDayLow + Fibolevel5 * step;
			double fibo6 = priorDayLow + Fibolevel6 * step;
			double fibo7 = priorDayLow + Fibolevel7 * step;
			double fibo8 = priorDayLow + Fibolevel8 * step;
			double fibo9 = priorDayLow + Fibolevel9 * step;
			double fibo10 = priorDayLow + Fibolevel10 * step;
			
			List<double> fibo = new List<double>();
			fibo.Add(fibo1);
			fibo.Add(fibo2);
			fibo.Add(fibo3);
			fibo.Add(fibo4);
			fibo.Add(fibo5);
			fibo.Add(fibo6);
			fibo.Add(fibo7);
			fibo.Add(fibo8);
			fibo.Add(fibo9);			
			fibo.Add(fibo10);

			if(ShowFibo){
				for (int i=0; i<fibo.Count; i++){
					Draw.HorizontalLine(this, "fibo" + i, fibo[i], Brushes.Black);
				}
			}
			
			if (State == State.Historical)				return;		
			if (!(ToTime(Time[0]) >= ToTime(StartTime) && ToTime(Time[0]) <= ToTime(EndTime))){return;}
			if (notrading){return;}
			

			for (int i=0; i<fibo.Count; i++){
				if (orderId[i].Length == 0 && atmStrategyId[i].Length == 0 && (CrossAbove(Close, fibo[i], 1) || CrossBelow(Close, fibo[i], 1)))
				{					
					isAtmStrategyCreated[i] = false;  // reset atm strategy created check to false
					atmStrategyId[i] = GetAtmStrategyUniqueId();
					orderId[i] = GetAtmStrategyUniqueId();
					
					if (i<5){
						AtmStrategyCreate(OrderAction.Sell, OrderType.Market, fibo[i], 0, TimeInForce.Gtc, orderId[i], "FiboStrategyTemplate", atmStrategyId[i], (atmCallbackErrorCode, atmCallBackId) => {
							//check that the atm strategy create did not result in error, and that the requested atm strategy matches the id in callback
							if (atmCallbackErrorCode == ErrorCode.NoError && atmCallBackId == atmStrategyId[i])
								isAtmStrategyCreated[i] = true;
						});
					}else{
						AtmStrategyCreate(OrderAction.Buy, OrderType.Market, fibo[i], 0, TimeInForce.Gtc, orderId[i], "FiboStrategyTemplate", atmStrategyId[i], (atmCallbackErrorCode, atmCallBackId) => {
							//check that the atm strategy create did not result in error, and that the requested atm strategy matches the id in callback
							if (atmCallbackErrorCode == ErrorCode.NoError && atmCallBackId == atmStrategyId[i])
								isAtmStrategyCreated[i] = true;
						});
					}
				}
				
				if (orderId[i].Length > 0)
				{
					string[] status = GetAtmStrategyEntryOrderStatus(orderId[i]);
	                
					// If the status call can't find the order specified, the return array length will be zero otherwise it will hold elements
					if (status.GetLength(0) > 0)
					{
						// If the order state is terminal, reset the order id value
						if (status[2] == "Filled" || status[2] == "Cancelled" || status[2] == "Rejected")
							orderId[i] = string.Empty;
					}
				} // If the strategy has terminated reset the strategy id after doing some profit/loss calculations.
				else if (atmStrategyId[i].Length > 0 && GetAtmStrategyMarketPosition(atmStrategyId[i]) == Cbi.MarketPosition.Flat)
				{
					/* Retrieve the profit or loss from the just-closed ATM strategy and round it to the nearest tick. This only updates after all targets or stops are filled (the position is flat).
					   GetAtmStrategyRealizedProfitLoss can return values such as 99.9999999998 or 100.00000000012, which would be rounded to 100. */
					realizedProfitLoss = Instrument.MasterInstrument.RoundToTickSize(GetAtmStrategyRealizedProfitLoss(atmStrategyId[i]));
					
					if (realizedProfitLoss > 0){
						if (DisableAfterSuccess){
							for (int j=0; j<orderId.Length;j++){							
								AtmStrategyClose(orderId[j]);
								notrading = true;
							}
						}
					}else if (realizedProfitLoss < 0) {
						if (DisableAfterFailed){
							MCL++;
						}
						
						if (MCL == tradingFailedCount) {
							for (int j=0; j<orderId.Length;j++){
								AtmStrategyClose(orderId[j]);
								notrading = true;
							}
						}
					}
						
					// Sum the profit to the running total.
//					totalPL = totalPL + realizedProfitLoss;
					
//					// Reset the strategy id and unrealized profit/loss variables because the strategy is now terminated.
//					atmStrategyId[i] = string.Empty;
//					unrealizedProfitLoss = 0;
				}
				
//				// Make sure atmStrategyId contains a value or GetAtmStrategyUnrealizedProfitLoss() will throw an error.
//				if (atmStrategyId[i].Length > 0)
//				{
//					unrealizedProfitLoss = Instrument.MasterInstrument.RoundToTickSize(GetAtmStrategyUnrealizedProfitLoss(atmStrategyId[i]));
//				}
				
//				// Concatenate all the information and then draw it onto the chart. '\r\n' basically just means new line.
//				string textToDraw = "Unrealized P/L: " + unrealizedProfitLoss.ToString() + "\r\nRealized P/L: " + totalPL.ToString() + "\r\nLast Strategy's P/L: " + realizedProfitLoss.ToString();
//				//Draw.TextFixed(this, "P/L information", textToDraw, TextPosition.BottomRight);
			}
		}		

		#region Properties
		
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="StartTime", Description="start trading after this time", Order=1, GroupName="Parameters")]
		public DateTime StartTime
		{ get; set; }

		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="EndTime", Description="end trading after this time", Order=2, GroupName="Parameters")]
		public DateTime EndTime
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel1", Order=3, GroupName="Parameters")]
		public double Fibolevel1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel2", Order=4, GroupName="Parameters")]
		public double Fibolevel2
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel3", Order=5, GroupName="Parameters")]
		public double Fibolevel3
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel4", Order=6, GroupName="Parameters")]
		public double Fibolevel4
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel5", Order=7, GroupName="Parameters")]
		public double Fibolevel5
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel6", Order=8, GroupName="Parameters")]
		public double Fibolevel6
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel7", Order=9, GroupName="Parameters")]
		public double Fibolevel7
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel8", Order=10, GroupName="Parameters")]
		public double Fibolevel8
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel9", Order=11, GroupName="Parameters")]
		public double Fibolevel9
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Fibolevel10", Order=12, GroupName="Parameters")]
		public double Fibolevel10
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="DisableAfterSuccess", Description="disable strategy after 1 successful trade for the day", Order=13, GroupName="Parameters")]
		public bool DisableAfterSuccess
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="DisableAfterFailed", Description="disable strategy after a certain number of failed trades for the day", Order=14, GroupName="Parameters")]
		public bool DisableAfterFailed
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="tradingFailedCount", Order=15, GroupName="Parameters")]
		public int tradingFailedCount
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowFibo", Order=16, GroupName="Parameters")]
		public bool ShowFibo
		{ get; set; }
		
		
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> PriorOpen
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> PriorHigh
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> PriorLow
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> PriorClose
		{
			get { return Values[3]; }
		}
		
		#endregion

	}
}
